<template>
    <div class="impressum">
      <h1>Legal Notice</h1>
      <p>© Stratagem 2025</p>
      <p>HTL Rennweg</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Impressum',
  };
  </script>
  
  <style scoped>
  @import '../styles/legalNotice.css';
  </style>
  