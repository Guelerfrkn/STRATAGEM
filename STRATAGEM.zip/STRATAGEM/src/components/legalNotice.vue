<template>
    <div class="impressum">
      <h1>Impressum</h1>
      <p>...</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Impressum',
  };
  </script>
  
  <style scoped>
  .impressum {
    padding: 20px;
  }
  
  .impressum h1 {
    margin-bottom: 10px;
  }
  </style>
  