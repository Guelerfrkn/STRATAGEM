<template>
  <article>
    <slot></slot>
  </article>
</template>

<script setup>
// No specific logic needed, content is inserted via slots.
</script>

<style scoped>
@import '../styles/Article.css';
</style>