<template>
    <article>
      <slot></slot>
    </article>
  </template>
  
  <script setup>
  // Keine spezifische Logik benötigt, der Inhalt wird über Slots eingefügt.
  </script>
  
  <style scoped>
  article {
    margin-bottom: 1.5em;
    line-height: 1.6;
  }
  
  /* Hier könnten weitere allgemeine Artikel-Stile stehen */
  </style>